# Patrick Odagiu - 05.04.2020
# B-decay to D mesons ntuple analysis.
# Produces one histogram of a specified process, with specified x-axis boundaries.

import ROOT as rt
import os, sys, glob
import argparse
# Defining a root_dir enables batch processing. Sorry... Change it to the root
# directory of your code tree.
root_dir = "/home/odagiu/"
# Set the root directory of this python project such that imports are easy.
sys.path.append(root_dir)

from util import data_handling as dhand
from histos import produce_histograms as ph

# Preamble with decays and input arguments -------------------------------------
decay_names = [os.path.basename(path) for path in
               glob.glob(os.path.join("bcdd_2011d", "*.root"))]
parser = argparse.ArgumentParser(description="Create a specific histogram")
parser.add_argument('-d', '--decay', default="0",
    choices=["0","1","2","3","4","5","6","7"], help=misc.channel_explanation)
parser.add_argument('-r', '--run', default="1",
    choices=["1", "2"], help="Run 1 or 2.")
parser.add_argument('-b', '--branch', help="Year")
parser.add_argument('-lim1', '--lowlimit', default="0",
    help="Lower limit of the histogram.")
parser.add_argument('-lim2', '--uplimit', default="0",
    help="Upper limit of the histogram.")
args = parser.parse_args()
args.decay = int(args.decay); args.run = int(args.run)
args.lowlimit = float(args.lowlimit); args.uplimit = float(args.uplimit)
# End preamble -----------------------------------------------------------------

def activate_branch(decay_name):
    # Return montecarlo and data trees with only one branch activated
    # as specified by the user in the input.
    moca_tree = dhand.combine_trees(args.run, decay_name, True)
    data_tree = dhand.combine_trees(args.run, decay_name, False)
    moca_tree.SetBranchStatus(args.branch, 1)
    data_tree.SetBranchStatus(args.branch, 1)

    return data_tree, moca_tree

if __name__ == '__main__':
    # Create specific directory in home of user where the histogram is stored.
    decay_name = decay_names[args.decay]
    directory_name = os.path.join(os.path.expanduser("~"), "histos", decay_name[:-17])
    if not os.path.exists(directory_name):
        os.mkdir(directory_name)

    data_tree, moca_tree = activate_branch(decay_name)
    # Finally, create the overlay histogram.
    ph.create_overlay_histogram(data_tree, moca_tree, args.branch, args.run,
                                decay_name[:-17], args.lowlimit, args.uplimit)


