from __future__ import division
import ROOT
from ROOT import RooRealVar, RooDataSet, RooArgSet, RooCBShape, RooAddPdf
from ROOT import RooGaussian, RooExponential, RooArgList, RooBreitWigner
from ROOT import RooSimultaneous, RooCategory, RooLinkedList
from ROOT import RooFit, RooChi2Var, TFile, RooAbsReal, RooMsgService
import sys, glob, os, argparse, array, math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Defining a root_dir enables batch processing. Sorry... Change it to the root
# directory of your code tree.
root_dir = "/home/odagiu/"
# Set the root directory of this python project such that imports are easy.
sys.path.append(root_dir)
from util import data_handling as dhand
from util import misc
from histos import produce_histograms as phist

# Preamble with input variables and list of studyied decays --------------------
decay_names    = [os.path.basename(path) for path in
                  glob.glob(os.path.join("bcdd_2011d", "*.root"))]

parser = argparse.ArgumentParser(description="Add MVA response to ntuples.")
parser.add_argument('-d', '--decay', default="0",
    choices=["0","1","2","3","4","5","6","7"], help=misc.channel_explanation)
parser.add_argument('-r', '--run', default="1",
    choices=["1", "2"], help="Run 1 or 2.")
parser.add_argument('-f', '--fname', default="fit", help="Output file name.")
parser.add_argument('-p', '--plot', default="0", choices=["0","1"], help="To plot or not.")
parser.add_argument('-c', '--cut', default="-1", help="Apply a BDT cut.")
args = parser.parse_args()
args.decay = int(args.decay); args.run = int(args.run); args.plot = int(args.plot)
args.cut = float(args.cut)

data_dir    = os.path.join(root_dir, "MLclass", "ntuples")
output_dir  = os.path.join(root_dir, "fits", "fits")
branches = ["_ID", "BDT_G"]
RooMsgService.instance().setSilentMode(True)
RooMsgService.instance().setGlobalKillBelow(RooFit.ERROR)
# End preamble -----------------------------------------------------------------

def get_active_branches(tree):
    active_branches = []
    new_tree = tree.CloneTree(0)
    for branch in new_tree.GetListOfBranches():
        active_branches.append(branch.GetName())

    return active_branches

def define_cuts(decay_nb):
    """
    Gets and ignores branches depending on the decay. This is for fine tuning
    the MVA.

    @decay_nb  :: Decay number, selected by user.

    @returns :: a list of branches that should be ignored.
    """
    switcher = {
        0: lambda : decay0_cut(),
        1: lambda : decay1_cut(),
        2: lambda : decay2_cut(),
        3: lambda : decay3_cut(),
        4: lambda : decay4_cut(),
        5: lambda : decay5_cut(),
        6: lambda : decay6_cut(),
        7: lambda : decay7_cut()
    }
    func = switcher.get(decay_nb, lambda : "Invalid decay number")
    idcuts = func()

    return idcuts

def decay0_cut():
    Bp_sel = "(p1_ID==+211&&p2_ID==+211&&p3_ID==-321&&z1_ID==+321&&z2_ID==-211)"
    Bm_sel = "(p1_ID==-211&&p2_ID==-211&&p3_ID==+321&&z1_ID==-321&&z2_ID==+211)"

    return Bp_sel + "||" + Bm_sel

def decay1_cut():
    Bp_sel = "(p1_ID==+211&&p2_ID==+211&&p3_ID==-321&&z1_ID==+321&&z2_ID==-211&&z3_ID==+211&&z4_ID==-211)"
    Bm_sel = "(p1_ID==-211&&p2_ID==-211&&p3_ID==+321&&z1_ID==-321&&z2_ID==+211&&z3_ID==-211&&z4_ID==+211)"

    return Bp_sel + "||" + Bm_sel

def decay2_cut():
    Bp_sel = "(p1_ID==+321&&p2_ID==+211&&p3_ID==-321&&z1_ID==+321&&z2_ID==-211)"
    Bm_sel = "(p1_ID==-321&&p2_ID==-211&&p3_ID==+321&&z1_ID==-321&&z2_ID==+211)"

    return Bp_sel + "||" + Bm_sel

def decay3_cut():
    Bp_sel = "(p1_ID==+321&&p2_ID==+211&&p3_ID==-321&&z1_ID==+321&&z2_ID==-211&&z3_ID==+211&&z4_ID==-211)"
    Bm_sel = "(p1_ID==-321&&p2_ID==-211&&p3_ID==+321&&z1_ID==-321&&z2_ID==+211&&z3_ID==-211&&z4_ID==+211)"

    return Bp_sel + "||" + Bm_sel

def decay4_cut():
    Bp_sel = "(p1_ID==-321&&p2_ID==+211&&z1_ID==+321&&z2_ID==-211)"
    Bm_sel = "(p1_ID==+321&&p2_ID==-211&&z1_ID==-321&&z2_ID==+211)"

    return Bp_sel + "||" + Bm_sel

def decay5_cut():
    Bp_sel = "(p1_ID==-321&&p2_ID==+211&&z1_ID==+321&&z2_ID==-211&&z3_ID==+211&&z4_ID==-211)"
    Bm_sel = "(p1_ID==+321&&p2_ID==-211&&z1_ID==-321&&z2_ID==+211&&z3_ID==-211&&z4_ID==+211)"

    return Bp_sel + "||" + Bm_sel

def decay6_cut():
    Bp_sel = "(p1_ID==-321&&p2_ID==+211&&p3_ID==-211&&p4_ID==+211&&z1_ID==+321&&z2_ID==-211)"
    Bm_sel = "(p1_ID==+321&&p2_ID==-211&&p3_ID==+211&&p4_ID==-211&&z1_ID==-321&&z2_ID==+211)"

    return Bp_sel + "||" + Bm_sel

def decay7_cut():
    Bp_sel = "(p1_ID==-321&&p2_ID==+211&&p3_ID==-211&&p4_ID==+211&&z1_ID==+321&&z2_ID==-211&&z3_ID==+211&&z4_ID==-211)"
    Bm_sel = "(p1_ID==+321&&p2_ID==-211&&p3_ID==+211&&p4_ID==-211&&z1_ID==-321&&z2_ID==+211&&z3_ID==-211&&z4_ID==+211)"

    return Bp_sel + "||" + Bm_sel

def ignore_branches(tree):
    ignore_branches = ["runNumber", "Ds_ID", "Dp_ID", "Dz_ID", "Dst_ID", "Bc_ID", "ps_ID", "Dzs_ID"]
    for branch in tree.GetListOfBranches():
        if branch.GetName() in ignore_branches: tree.SetBranchStatus(branch.GetName(), 0)

    return tree

def model_comparison(Bc_DTF_M_Bc, data):
    # Models for fit.
    # Crystal ball sum.
    cb_mean = RooRealVar("mean", "B^{+} mean", 5278, 5220, 5340)
    cb_sigma1 = RooRealVar("sigma1", "B^{+} sigma 1", 5.0, 0, 20)
    cb_sigma2 = RooRealVar("sigma2", "B^{+} sigma 2", 15, 0, 50)
    cb_a1 = RooRealVar("a1", "B^{+} tail param 1",-10.0, 0.0)
    cb_a2 = RooRealVar("a2", "B^{+} tail param 2", 0.0, 10.0)
    cb_n = RooRealVar("n", "B^{+} power param", 2.0)
    cb1 = RooCBShape("cb1", "B^{+} cb1", Bc_DTF_M_Bc, cb_mean, cb_sigma1, cb_a1, cb_n)
    cb2 = RooCBShape("cb2", "B^{+} cb2", Bc_DTF_M_Bc, cb_mean, cb_sigma2, cb_a2, cb_n)
    cbf = RooRealVar("cbf", "CB fraction", 0.0, 1.0)
    cb_sum = RooAddPdf("cb_sum", "cb_sum", cb1, cb2, cbf)

    # Gaussian sum.
    ga_mean = RooRealVar("gamean", "B^{+} gamean", 5278, 5220, 5340)
    ga_sigma1 = RooRealVar("gasigma1", "B^{+} gasigma 1", 5.0, 0, 45)
    ga_sigma2 = RooRealVar("gasigma2", "B^{+} gasigma 2", 45, 0, 50)
    ga1 = RooGaussian("ga1","B^{+} ga1", Bc_DTF_M_Bc, ga_mean, ga_sigma1)
    ga2 = RooGaussian("ga2","B^{+} ga2", Bc_DTF_M_Bc, ga_mean, ga_sigma2)
    gaf = RooRealVar("gaf", "Ga fraction", 0.0, 1.0)
    ga_sum = RooAddPdf("ga_model", "ga_model", ga1, ga2, gaf)

    # Breit Wigner.
    bw_mean = RooRealVar("bwmean", "B^{+} bwmean", 5278, 5220, 5340)
    bw_sigma = RooRealVar("bwsigma", "B^{+} bwsigma", 5.0, 0, 20)
    bwi = RooBreitWigner("bwi","B^{+} bwi", Bc_DTF_M_Bc, bw_mean, bw_sigma)

    # Add nsig and construct final models.
    nSig = RooRealVar("nSig", "nSig", 1e4, 0., 1e6)
    bwi_model = RooAddPdf("bwimodel", "bwimodel", RooArgList(bwi), RooArgList(nSig))
    cbs_model = RooAddPdf("cbsmodel", "cbsmodel", RooArgList(cb_sum), RooArgList(nSig))
    gas_model = RooAddPdf("gasmodel", "gasmodel", RooArgList(ga_sum), RooArgList(nSig))

    # Fit.
    result_cbs = cbs_model.fitTo(data, RooFit.Save(True))
    result_bwi = bwi_model.fitTo(data, RooFit.Save(True))
    result_gas = gas_model.fitTo(data, RooFit.Save(True))

    # Plot the fit.
    frame = Bc_DTF_M_Bc.frame(5230., 5330., 100)
    data.plotOn(frame, RooFit.Name("data"))
    cbs_model.plotOn(frame, RooFit.Name("cbsmodel"), RooFit.LineColor(ROOT.kRed))
    bwi_model.plotOn(frame, RooFit.Name("bwimodel"), RooFit.LineColor(ROOT.kBlue))
    gas_model.plotOn(frame, RooFit.Name("gasmodel"), RooFit.LineColor(ROOT.kGreen))

    chi2_cbs = frame.chiSquare("cbsmodel", "data", 6)
    chi2_bwi = frame.chiSquare("bwimodel", "data", 2)
    chi2_gas = frame.chiSquare("gasmodel", "data", 3)

    legend = ROOT.TLegend(0.6, 0.7, 0.85, 0.85)
    legend.SetFillColor(ROOT.kWhite)
    legend.SetLineColor(ROOT.kWhite)

    entry_cbs = legend.AddEntry(None, "Crystall Ball #chi^{2} = " + str(round(chi2_cbs, 2)), "l")
    entry_gas = legend.AddEntry(None, "Gaussian #chi^{2} = " + str(round(chi2_gas, 2)), "l")
    entry_bwi = legend.AddEntry(None, "Breit-Wigner #chi^{2} = " + str(round(chi2_bwi, 2)), "l")

    entry_cbs.SetLineColor(ROOT.kRed);   entry_cbs.SetLineWidth(2)
    entry_gas.SetLineColor(ROOT.kGreen); entry_gas.SetLineWidth(2)
    entry_bwi.SetLineColor(ROOT.kBlue);  entry_bwi.SetLineWidth(2)

    os.chdir(output_dir)
    c = ROOT.TCanvas("c", "c", 900, 600)
    frame.Draw()
    legend.Draw("same")
    c.Print(args.fname + "_" + str(args.decay) + ".pdf")

def single_cut_fit(bdt_cut, Bc_DTF_M_Bc, BDT_G, mc_data, re_data, plotting):
    # Cut on the BDT response and construct rescale factor.
    print("\nDoing the single fitting to determined params...")
    mc_cut = mc_data.reduce(RooArgSet(Bc_DTF_M_Bc, BDT_G),"BDT_G > " + str(bdt_cut))
    if mc_cut.numEntries() <=0: print("No mc events. Can't fit."); return 0
    mc_rescale = (mc_data.numEntries() - mc_cut.numEntries())/mc_data.numEntries()

    # Crystal ball subplotm for fitting MC.
    cb_mean = RooRealVar("mean", "B^{+} mean", 5278, 5220, 5340)
    cb_sigma1 = RooRealVar("sigma1", "B^{+} sigma 1", 5.0, 0, 20)
    cb_sigma2 = RooRealVar("sigma2", "B^{+} sigma 2", 15, 0, 50)
    cb_a1 = RooRealVar("a1", "B^{+} tail param 1",-10.0, 0.0)
    cb_a2 = RooRealVar("a2", "B^{+} tail param 2", 0.0, 10.0)
    cb_n = RooRealVar("n", "B^{+} power param", 2.0)
    cb1 = RooCBShape("cb1", "B^{+} cb1", Bc_DTF_M_Bc, cb_mean, cb_sigma1, cb_a1, cb_n)
    cb2 = RooCBShape("cb2", "B^{+} cb2", Bc_DTF_M_Bc, cb_mean, cb_sigma2, cb_a2, cb_n)
    cbf = RooRealVar("cbf", "CB fraction", 0.0, 1.0)
    cb_sum = RooAddPdf("cb_sum", "cb_sum", cb1, cb2, cbf)

    # Add nsig/nbkg and construct final models.
    nSig = RooRealVar("nSig", "nSig", 1e4,  0., 1e6)
    nBkg = RooRealVar("nBkg", "nBkg", 1e2, 0., 1e6)
    cbs_model = RooAddPdf("cbsmodel", "cbsmodel", RooArgList(cb_sum), RooArgList(nSig))

    # Fitting results.
    result_mc = cbs_model.fitTo(mc_cut, RooFit.Save(True))

    # Crystal ball sum for fitting data.
    cbr_mean = RooRealVar("rmean", "B^{+} rmean", cb_mean.getVal())
    cbr_sigma1 = RooRealVar("rsigma1", "B^{+} rsigma 1", cb_sigma1.getVal())
    cbr_sigma2 = RooRealVar("rsigma2", "B^{+} rsigma 2", cb_sigma2.getVal(), 0, 50)
    cbr_a1 = RooRealVar("ra1", "B^{+} rtail param 1", cb_a1.getVal())
    cbr_a2 = RooRealVar("ra2", "B^{+} rtail param 2", cb_a2.getVal())
    cbr_n = RooRealVar("rn", "B^{+} rpower param", 2.0)
    cbr1 = RooCBShape("cbr1", "B^{+} cbr1", Bc_DTF_M_Bc, cbr_mean, cbr_sigma1, cbr_a1, cbr_n)
    cbr2 = RooCBShape("cbr2", "B^{+} cbr2", Bc_DTF_M_Bc, cbr_mean, cbr_sigma2, cbr_a2, cbr_n)
    cbrf = RooRealVar("cbrf", "CB rfraction", cbf.getVal())
    cbr_sum = RooAddPdf("cbr_sum", "cbr_sum", cbr1, cbr2, cbrf)

    # Exponentail fit.
    exponent = RooRealVar("exponent", "exponent", -1e-13, -1, 1)
    exr_mod = RooExponential("exr_mod", "exr_mod", Bc_DTF_M_Bc, exponent)

    # Data model.
    re_model = RooAddPdf("remodel", "remodel", RooArgList(cbr_sum, exr_mod), RooArgList(nSig, nBkg))
    re_cut   = re_data.reduce(RooArgSet(Bc_DTF_M_Bc, BDT_G),"BDT_G > " + str(bdt_cut))
    if re_cut.numEntries() <=0: print("No data events. Can't fit."); return 0

    result_re = re_model.fitTo(re_cut, RooFit.Save(True))

    data_vars = [cbr_mean.getVal(), cbr_sigma1.getVal(), cbr_sigma2.getVal(),
                 cbr_a1.getVal(), cbr_a2.getVal(), cbr_n.getVal(), cbrf.getVal(),
                 exponent.getVal()]
    moca_vars = [cb_mean.getVal(), cb_sigma1.getVal(), cb_sigma2.getVal(),
                 cb_a1.getVal(), cb_a2.getVal(), cb_n.getVal(), cbf.getVal()]

    print("Parameters determined succesfully...")
    return np.array([moca_vars, data_vars])


def fom_fitting(bdt_cut, Bc_DTF_M_Bc, BDT_G, mc_data, re_data, vs, plotting):
    # Cut on the BDT response and construct rescale factor.
    print("\nThe BDT cut :" + str(bdt_cut))
    mc_cut = mc_data.reduce(RooArgSet(Bc_DTF_M_Bc, BDT_G),"BDT_G > " + str(bdt_cut))
    if mc_cut.numEntries() <=0: print("No mc events. Can't fit."); return 0
    mc_rescale = mc_cut.numEntries()/mc_data.numEntries()

    # Crystal ball subplotm for fitting MC.
    cb_mean = RooRealVar("mean", "B^{+} mean", vs[0][0])
    cb_sigma1 = RooRealVar("sigma1", "B^{+} sigma 1", vs[0][1])
    cb_sigma2 = RooRealVar("sigma2", "B^{+} sigma 2", vs[0][2])
    cb_a1 = RooRealVar("a1", "B^{+} tail param 1",vs[0][3])
    cb_a2 = RooRealVar("a2", "B^{+} tail param 2", vs[0][4])
    cb_n = RooRealVar("n", "B^{+} power param", vs[0][5])
    cb1 = RooCBShape("cb1", "B^{+} cb1", Bc_DTF_M_Bc, cb_mean, cb_sigma1, cb_a1, cb_n)
    cb2 = RooCBShape("cb2", "B^{+} cb2", Bc_DTF_M_Bc, cb_mean, cb_sigma2, cb_a2, cb_n)
    cbf = RooRealVar("cbf", "CB fraction", vs[0][6])
    cb_sum = RooAddPdf("cb_sum", "cb_sum", cb1, cb2, cbf)

    # Add nsig/nbkg and construct final models.
    nSig = RooRealVar("nSig", "nSig", 1e4,  0., 1e6)
    nBkg = RooRealVar("nBkg", "nBkg", 1e2, 0., 1e6)
    cbs_model = RooAddPdf("cbsmodel", "cbsmodel", RooArgList(cb_sum), RooArgList(nSig))

    # Fitting results.
    result_mc = cbs_model.fitTo(mc_cut, RooFit.Save(True))

    # Crystal ball sum for fitting data.
    cbr_mean = RooRealVar("rmean", "B^{+} rmean", vs[1][0])
    cbr_sigma1 = RooRealVar("rsigma1", "B^{+} rsigma 1", vs[1][1])
    cbr_sigma2 = RooRealVar("rsigma2", "B^{+} rsigma 2", vs[1][2])
    cbr_a1 = RooRealVar("ra1", "B^{+} rtail param 1", vs[1][3])
    cbr_a2 = RooRealVar("ra2", "B^{+} rtail param 2", vs[1][4])
    cbr_n = RooRealVar("rn", "B^{+} rpower param", vs[1][5])
    cbr1 = RooCBShape("cbr1", "B^{+} cbr1", Bc_DTF_M_Bc, cbr_mean, cbr_sigma1, cbr_a1, cbr_n)
    cbr2 = RooCBShape("cbr2", "B^{+} cbr2", Bc_DTF_M_Bc, cbr_mean, cbr_sigma2, cbr_a2, cbr_n)
    cbrf = RooRealVar("cbrf", "CB rfraction", vs[1][6])
    cbr_sum = RooAddPdf("cbr_sum", "cbr_sum", cbr1, cbr2, cbrf)

    # Exponentail fit.
    exponent = RooRealVar("exponent", "exponent", vs[1][7])
    exr_mod = RooExponential("exr_mod", "exr_mod", Bc_DTF_M_Bc, exponent)

    # Data model.
    re_model = RooAddPdf("remodel", "remodel", RooArgList(cbr_sum, exr_mod), RooArgList(nSig, nBkg))
    re_cut   = re_data.reduce(RooArgSet(Bc_DTF_M_Bc, BDT_G),"BDT_G > " + str(bdt_cut))
    if re_cut.numEntries() <=0: print("No data events."); return 0
    result_re = re_model.fitTo(re_cut, RooFit.Save(True))

    # Calculate the figure of merit.
    sig_comp = re_model.pdfList().find("cbr_sum")
    bkg_comp = re_model.pdfList().find("exr_mod")

    integration_range  = Bc_DTF_M_Bc.setRange("int_range", 5245, 5305)
    int_sig = sig_comp.createIntegral(RooArgSet(Bc_DTF_M_Bc), RooArgSet(Bc_DTF_M_Bc), "int_range")
    int_bkg = bkg_comp.createIntegral(RooArgSet(Bc_DTF_M_Bc), RooArgSet(Bc_DTF_M_Bc), "int_range")

    sig_yield = nSig.getVal()
    bkg_yield = nBkg.getVal()
    print("Signal yield: ", sig_yield)
    print("Background yield: ", bkg_yield)

    if sig_yield + bkg_yield > 0 and isinstance(sig_yield, float) and isinstance(bkg_yield, float):
        figure_of_merit = sig_yield/math.sqrt(sig_yield + bkg_yield)
    else:
        figure_of_merit = 0

    print("Figure of merit: ", figure_of_merit)
    return figure_of_merit


def CP_determination(bdt_cut, argus, mc_data, re_data, idcuts, vs):
    print("\nThe BDT cut :" + str(bdt_cut))
    mc_cut = mc_data.reduce(argus, "BDT_G > " + str(bdt_cut))
    mc_rescale = mc_cut.numEntries()/mc_data.numEntries()
    idcuts = idcuts.split("||")
    re_cut = re_data.reduce(argus,"BDT_G > " + str(bdt_cut))
    re_Bp  = re_cut.reduce(argus, idcuts[0])
    re_Bm  = re_cut.reduce(argus, idcuts[1])

    # Crystal ball subplotm for fitting MC.
    cb_mean = RooRealVar("mean", "B^{+} mean", vs[0][0])
    cb_sigma1 = RooRealVar("sigma1", "B^{+} sigma 1", vs[0][1])
    cb_sigma2 = RooRealVar("sigma2", "B^{+} sigma 2", vs[0][2])
    cb_a1 = RooRealVar("a1", "B^{+} tail param 1",vs[0][3])
    cb_a2 = RooRealVar("a2", "B^{+} tail param 2", vs[0][4])
    cb_n = RooRealVar("n", "B^{+} power param", vs[0][5])
    cb1 = RooCBShape("cb1", "B^{+} cb1", Bc_DTF_M_Bc, cb_mean, cb_sigma1, cb_a1, cb_n)
    cb2 = RooCBShape("cb2", "B^{+} cb2", Bc_DTF_M_Bc, cb_mean, cb_sigma2, cb_a2, cb_n)
    cbf = RooRealVar("cbf", "CB fraction", vs[0][6])
    cb_sum = RooAddPdf("cb_sum", "cb_sum", cb1, cb2, cbf)

    # Add nsig/nbkg and construct final models.
    nSig = RooRealVar("nSig", "nSig", 1e4,  0., 1e6)
    nBkg = RooRealVar("nBkg", "nBkg", 1e2, 0., 1e6)
    cbs_model = RooAddPdf("cbsmodel", "cbsmodel", RooArgList(cb_sum), RooArgList(nSig))

    # Fitting results.
    result_mc = cbs_model.fitTo(mc_cut, RooFit.Save(True))

    # Crystal ball sum for fitting data.
    cbr_mean = RooRealVar("rmean", "B^{+} rmean", vs[1][0])
    cbr_sigma1 = RooRealVar("rsigma1", "B^{+} rsigma 1", vs[1][1])
    cbr_sigma2 = RooRealVar("rsigma2", "B^{+} rsigma 2", vs[1][2])
    cbr_a1 = RooRealVar("ra1", "B^{+} rtail param 1", vs[1][3])
    cbr_a2 = RooRealVar("ra2", "B^{+} rtail param 2", vs[1][4])
    cbr_n = RooRealVar("rn", "B^{+} rpower param", vs[1][5])
    cbr1 = RooCBShape("cbr1", "B^{+} cbr1", Bc_DTF_M_Bc, cbr_mean, cbr_sigma1, cbr_a1, cbr_n)
    cbr2 = RooCBShape("cbr2", "B^{+} cbr2", Bc_DTF_M_Bc, cbr_mean, cbr_sigma2, cbr_a2, cbr_n)
    cbrf = RooRealVar("cbrf", "CB rfraction", vs[1][6])
    cbr_sum = RooAddPdf("cbr_sum", "cbr_sum", cbr1, cbr2, cbrf)

    # Exponentail fit.
    exponent = RooRealVar("exponent", "exponent", vs[1][7])
    exr_mod = RooExponential("exr_mod", "exr_mod", Bc_DTF_M_Bc, exponent)

    # Data model.
    re_model = RooAddPdf("remodel", "remodel", RooArgList(cbr_sum, exr_mod), RooArgList(nSig, nBkg))
    Bp_result = re_model.fitTo(re_Bp, RooFit.Save(True))

    # B+ signal yield calculation.
    sig_comp = re_model.pdfList().find("cbr_sum")
    bkg_comp = re_model.pdfList().find("exr_mod")

    integration_range = Bc_DTF_M_Bc.setRange("int_range", 5245, 5305)
    int_sig = sig_comp.createIntegral(RooArgSet(Bc_DTF_M_Bc), RooArgSet(Bc_DTF_M_Bc), "int_range")
    int_bkg = bkg_comp.createIntegral(RooArgSet(Bc_DTF_M_Bc), RooArgSet(Bc_DTF_M_Bc), "int_range")

    Bp_sig_yield = nSig.getVal()
    Bp_bkg_yield = nBkg.getVal()
    Bp_sig_error = nSig.getError()
    Bp_bkg_error = nBkg.getError()

    print("B+ Signal yield: ", Bp_sig_yield)
    print("B+ Background yield: ", Bp_sig_error)

    Bm_result = re_model.fitTo(re_Bm, RooFit.Save(True))

    # B- signal yield calculation.
    sig_comp = re_model.pdfList().find("cbr_sum")
    bkg_comp = re_model.pdfList().find("exr_mod")

    int_sig = sig_comp.createIntegral(RooArgSet(Bc_DTF_M_Bc), RooArgSet(Bc_DTF_M_Bc), "int_range")
    int_bkg = bkg_comp.createIntegral(RooArgSet(Bc_DTF_M_Bc), RooArgSet(Bc_DTF_M_Bc), "int_range")

    Bm_sig_yield = nSig.getVal()
    Bm_bkg_yield = nBkg.getVal()
    Bm_sig_error = nSig.getError()
    Bm_bkg_error = nBkg.getError()
    print("B- Signal yield: ", Bm_sig_yield)
    print("B- Background yield: ", Bm_sig_error)

    # Plotting.
    result_re = re_model.fitTo(re_cut, RooFit.Save(True))
    frame = Bc_DTF_M_Bc.frame(5230., 5370., 140)
    re_cut.plotOn(frame, RooFit.Name("re_data"))
    re_model.plotOn(frame, RooFit.Name("re_expmodel"), RooFit.LineColor(ROOT.kBlue),
                    RooFit.Components("exr_mod"))
    re_model.plotOn(frame, RooFit.Name("re_model_fit"), RooFit.LineColor(ROOT.kViolet))
    maximum = frame.GetMaximum()
    scale_factor = re_cut.sumEntries("Bc_DTF_M_Bc > 5260 && Bc_DTF_M_Bc < 5300")/mc_cut.sumEntries()
    mc_cut.plotOn(frame, RooFit.Name("mc_data"), RooFit.MarkerColor(ROOT.kOrange),
                    RooFit.Rescale(scale_factor))
    cbs_model.plotOn(frame, RooFit.Name("mc_cbsmodel"), RooFit.LineColor(ROOT.kRed),
                        RooFit.Range(5230, 5370))

    # Rescale the y axis after we rescaled the MC.
    frame.SetMaximum(maximum)
    legend = ROOT.TLegend(0.55, 0.6, 0.85, 0.85)
    legend.SetFillColor(ROOT.kWhite)
    legend.SetLineColor(ROOT.kWhite)
    entry_mon = legend.AddEntry(None, "Monte Carlo", "pe")
    entry_rea = legend.AddEntry(None, "Data", "pe")
    entry_cbs = legend.AddEntry(None, "MC CBall Sum", "l")
    entry_cbr = legend.AddEntry(None, "Data CBall Sum + Exp Background", "l")
    entry_exp = legend.AddEntry(None, "Exp Background", "l")
    entry_cbs.SetLineColor(ROOT.kRed);      entry_cbs.SetLineWidth(2)
    entry_cbr.SetLineColor(ROOT.kViolet);   entry_cbr.SetLineWidth(2)
    entry_exp.SetLineColor(ROOT.kBlue);     entry_exp.SetLineWidth(2)
    entry_mon.SetMarkerColor(ROOT.kOrange); entry_mon.SetMarkerStyle(ROOT.kFullCircle)
    entry_rea.SetMarkerStyle(ROOT.kFullCircle)
    # Save plots of fitted data and montecarlo.
    os.chdir(output_dir)
    c = ROOT.TCanvas("c", "c", 900, 600)
    frame.Draw()
    legend.Draw("same")
    c.Print(args.fname + "_" + str(args.decay) + ".png")

    return np.array([Bm_sig_yield, Bm_sig_error, Bp_sig_yield, Bp_sig_error])

if __name__ == '__main__':
    # Create the output directory and get the decay name.
    misc.create_dir(output_dir)
    decay_name  = decay_names[args.decay]

    # Import the data into TChains
    moca_file = TFile(os.path.join(data_dir, decay_name[:-17] + "_moca.root"))
    moca_tree = moca_file.Get("DecayTree"); moca_tree.SetBranchStatus("*", 0)
    moca_tree = dhand.branch_selection(moca_tree, branches, [])
    moca_tree = ignore_branches(moca_tree)

    data_file = TFile(os.path.join(data_dir, decay_name[:-17] + "_data.root"))
    data_tree = data_file.Get("DecayTree"); data_tree.SetBranchStatus("*", 0)
    data_tree = dhand.branch_selection(data_tree, branches, [])
    data_tree = ignore_branches(data_tree)

    active_branches = get_active_branches(moca_tree)
    # Define the variables.
    for branch in active_branches:
        if branch == "Bc_DTF_M_Bc": Bc_DTF_M_Bc = RooRealVar("Bc_DTF_M_Bc",
            "m_{B^{+}}", 5280., 5230., 6700., "MeV/c^{2}")
        elif branch == "BDT_G":  BDT_G = RooRealVar("BDT_G", "BDT_G", 0.5, 0, 1)
        else: exec(branch + " = RooRealVar(\"" + branch + "\",\"" + branch +\
                   "\", -1.e3, 1.e3)")

    argus = RooArgSet()
    for branch in active_branches:
        exec("argus.add(" + branch + ")")
    # Define the cuts and the roo dataset.
    idcuts = define_cuts(args.decay)
    re_data_str = "re_data = RooDataSet(\"redata\", \"redata\", argus, \
                   RooFit.Import(data_tree), RooFit.Cut(\"" + idcuts + "\"))"
    mc_data_str = "mc_data = RooDataSet(\"mcdata\", \"mcdata\", argus, \
                   RooFit.Import(moca_tree), RooFit.Cut(\"" + idcuts + "\"))"
    exec(mc_data_str); exec(re_data_str)

    plotting = args.plot

    arguments = Bc_DTF_M_Bc, BDT_G, mc_data, re_data, plotting
    vs = single_cut_fit(-1, Bc_DTF_M_Bc, BDT_G, mc_data, re_data, plotting)
    if plotting is 0:
        if args.cut != -1: print("You need to set -p 1 for cut to be applied.")
        bdt_cuts = np.linspace(-0.5, 0.5, 300)
        vfitting = np.vectorize(fom_fitting, excluded = [1, 2, 3, 4, 5, 6])
        yfitting = vfitting(bdt_cuts, Bc_DTF_M_Bc, BDT_G, mc_data, re_data, vs, plotting)

        data_array = np.array([bdt_cuts, yfitting])
        os.chdir(output_dir)
        fig, ax = plt.subplots(figsize=(8,6))
        ax.plot(bdt_cuts, yfitting, label='Figure of Merit')
        ax.set(xlabel='BDT cut', ylabel='Figure of Merit');
        ax.legend()
        plt.savefig("fom_" + str(args.decay) + ".png")
        np.savetxt("fom_" + str(args.decay) + ".csv", data_array, delimiter = ',')

    else:
        bdt_cut = args.cut
        cp_array = CP_determination(bdt_cut, argus, mc_data, re_data, idcuts, vs)
        np.savetxt("cp_" + str(args.decay) + ".csv", cp_array, delimiter = ',')




