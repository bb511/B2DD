#!/bin/bash
python ~/MLclass/submit.py -d run2_fit -n decay0 "python fitting.py -d 0 -r 2 -p 1 -c 0.099"
python ~/MLclass/submit.py -d run2_fit -n decay1 "python fitting.py -d 1 -r 2 -p 1 -c 0.11"
python ~/MLclass/submit.py -d run2_fit -n decay2 "python fitting.py -d 2 -r 2 -p 1 -c 0.062"
python ~/MLclass/submit.py -d run2_fit -n decay3 "python fitting.py -d 3 -r 2 -p 1 -c 0.075"
python ~/MLclass/submit.py -d run2_fit -n decay4 "python fitting.py -d 4 -r 2 -p 1 -c 0.075"
python ~/MLclass/submit.py -d run2_fit -n decay5 "python fitting.py -d 5 -r 2 -p 1 -c 0.089"
python ~/MLclass/submit.py -d run2_fit -n decay6 "python fitting.py -d 6 -r 2 -p 1 -c 0.085"
python ~/MLclass/submit.py -d run2_fit -n decay7 "python fitting.py -d 7 -r 2 -p 1 -c 0.062"
