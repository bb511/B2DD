# Adds the MVA response to the root ntuples of the data and monte carol files.
# THE SCRIPT ONLY WORKS FOR THE 12TH TRY CURRENTLY, AS IT WAS FOUND TO BE
# THE BEST ONE. SEE WEBSITE FOR COMBINATION OF VARIABLES FOR SCHEME 12TH.
from ROOT import TFile, TTree, TChain, TObject, TMVA, TH1D, TCanvas
import sys, glob, os, argparse
import array

# Defining a root_dir enables batch processing. Sorry... Change it to the root
# directory of your code tree.
root_dir = "/home/odagiu/"
# Set the root directory of this python project such that imports are easy.
sys.path.append(root_dir)
from util import data_handling as dhand
from util import misc
from util import tmva_selection

# Preamble with input variables and list of studyied decays --------------------
decay_names    = [os.path.basename(path) for path in
                  glob.glob(os.path.join("bcdd_2011d", "*.root"))]

parser = argparse.ArgumentParser(description="Add MVA response to ntuples.")
parser.add_argument('-d', '--decay', default="0",
    choices=["0","1","2","3","4","5","6","7"], help=misc.channel_explanation)
parser.add_argument('-r', '--run', default="1",
    choices=["1", "2"], help="Run 1 or 2.")
parser.add_argument('-k', '--kfolds', default="1",
    choices=["1","2","3","4","5"], help="Number of kfolds.")
parser.add_argument('-m', '--mva', default="BDT_I",
    choices=["BDT_I", "BDT_U", "BDT_G", "BDT_GD", "BDT_GP"], help="MVA algorithm")
parser.add_argument('-s', '--set', default="0",
    choices=["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"],
    help="MVA algorithm")
args = parser.parse_args()
args.decay = int(args.decay); args.kfolds = int(args.kfolds); args.run = int(args.run)
decay_name = decay_names[args.decay]

MLclass_dir  = os.path.join(root_dir, "MLclass")
ntuples_dir  = os.path.join(MLclass_dir, "ntuples")
branches = ["_TAU", "_TAUERR", "_VCHI2", "_PT", "_PIDK", "_M",
            "_M13", "_M23", "_DM"]

# End preamble -----------------------------------------------------------------


def get_tree(decay_name, is_mc):

    tree = dhand.combine_trees(args.run, decay_name, is_mc)
    tree = dhand.branch_selection(tree, branches, [])
    ignore_branches = ["runNumber", "Bc_M", "Bc_DTF_M_Bc"]
    for branch in tree.GetListOfBranches():
        if branch.GetName() in ignore_branches: tree.SetBranchStatus(branch.GetName(), 0)

    return tree

def get_good_branches(tree):
    ignore   = tmva_selection.get_ignored_branches(args.decay)
    new_tree = tree.CloneTree(-1, "fast")
    new_tree = dhand.branch_selection(new_tree, branches, ignore)
    good_branches = misc.get_active_branches(new_tree)

    return good_branches

# Get the data.
decay_name  = decay_names[args.decay]
misc.create_dir(ntuples_dir)
new_data_file = TFile(os.path.join(ntuples_dir,decay_name[:-17] + "_data.root"), "recreate")
data_tree = get_tree(decay_name, False)
moca_tree = get_tree(decay_name, True)
good_brch = get_good_branches(data_tree)
print(good_brch)

# Create TMVA variables and readers.
for branch in good_brch:
        exec(branch + " = array.array('f',[0])")
Bc_TAUoTERR = array.array('f', [0])
Dp_TAUoTERR = array.array('f', [0])
Ds_TAUoTERR = array.array('f', [0])
Dz_TAUoTERR = array.array('f', [0])
Dalitz_mix  = array.array('f', [0])
runNumber = array.array('f', [0])

def create_tree_with_MVA(tree):
    """
    Clones the old tree and adds the MVA variable.
    @tree :: TTree to be copied and to add the MVA variable to.
    @returns :: The new TTree.
    """
    tree.SetBranchStatus("*_ID", 1)
    tree.SetBranchStatus("Bc_DTF_M_Bc", 1)
    new_tree   = tree.CloneTree(0)
    leaf       = args.mva + "/F"
    leaf_value = array.array("f", [0.0])
    new_branch = new_tree.Branch(args.mva, leaf_value, leaf)

    for event in tree:
        for branch in good_brch:
            exec(branch + "[0] = event." + branch)
        Bc_TAUoTERR[0] = event.Bc_TAU/event.Bc_TAUERR
        Dz_TAUoTERR[0] = event.Dz_TAU/event.Dz_TAUERR
        if args.decay == 0 or args.decay == 1:
            Dp_TAUoTERR[0] = event.Dp_TAU/event.Dp_TAUERR
            Dalitz_mix[0]  = max(event.Dp_M13, event.Dp_M23)
        if args.decay == 2 or args.decay == 3:
            Ds_TAUoTERR[0] = event.Ds_TAU/event.Ds_TAUERR

        for kfold in range(args.kfolds):
            if event.runNumber%5 == kfold: MVA_value = readers[kfold].EvaluateMVA(args.mva)
        leaf_value[0] = MVA_value
        new_tree.Fill()

    return new_tree

def book_readers(readers):
    # THESE VARIABLES ARE MATCHING THE TRY12 SCHEME. CAUTION WHEN WANTING TO
    # MAKE NTUPLES THAT ARE NOT TRY12. SEE WEBSITE FOR VARIABLES OF TRY12.
    for kfold in range(args.kfolds):
        if kfold == 5:
            break;
        if args.decay == 0:
            readers[kfold].AddVariable("Dp_M13_M23_Max := max(Dp_M13, Dp_M23)", Dalitz_mix)
            readers[kfold].AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR", Bc_TAUoTERR)
            readers[kfold].AddVariable("Dp_TAUoTERR := Dp_TAU/Dp_TAUERR", Dp_TAUoTERR)
            readers[kfold].AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR", Dz_TAUoTERR)
        if args.decay == 1:
            readers[kfold].AddVariable("Dp_M13_M23_Max := max(Dp_M13, Dp_M23)", Dalitz_mix)
            readers[kfold].AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR", Bc_TAUoTERR)
            readers[kfold].AddVariable("Dp_TAUoTERR := Dp_TAU/Dp_TAUERR", Dp_TAUoTERR)
            readers[kfold].AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR", Dz_TAUoTERR)
        if args.decay == 2:
            readers[kfold].AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR", Bc_TAUoTERR)
            readers[kfold].AddVariable("Ds_TAUoTERR := Ds_TAU/Ds_TAUERR", Ds_TAUoTERR)
            readers[kfold].AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR", Dz_TAUoTERR)
        if args.decay == 3:
            readers[kfold].AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR", Bc_TAUoTERR)
            readers[kfold].AddVariable("Ds_TAUoTERR := Ds_TAU/Ds_TAUERR", Ds_TAUoTERR)
            readers[kfold].AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR", Dz_TAUoTERR)
        if args.decay == 4:
            readers[kfold].AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR", Bc_TAUoTERR)
            readers[kfold].AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR", Dz_TAUoTERR)
        if args.decay == 5:
            readers[kfold].AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR", Bc_TAUoTERR)
            readers[kfold].AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR", Dz_TAUoTERR)
        if args.decay == 6:
            readers[kfold].AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR", Bc_TAUoTERR)
            readers[kfold].AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR", Dz_TAUoTERR)
        if args.decay == 7:
            readers[kfold].AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR", Bc_TAUoTERR)
            readers[kfold].AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR", Dz_TAUoTERR)
        readers[kfold].AddSpectator("runNumber", runNumber)
        for branch in good_brch:
            exec("readers[kfold].AddVariable(\"" + branch + "\"," + branch + ")")
        weights_path = os.path.join(MLclass_dir, "MVAoutput", "BDT_run" + \
            str(args.run) + "_" + str(args.set), "kfold_" + str(kfold), decay_name[:-17], \
            "dataloader", "weights")
        weights_file = os.path.join(weights_path, "TMVA_" + decay_name[:-17] + \
            "_" + args.mva + ".weights.xml")
        readers[kfold].BookMVA(args.mva, weights_file)

    return readers

if __name__ == '__main__':
    # Create TMVA reader for each kfold.
    readers   = {}
    for kfold in range(args.kfolds): readers[kfold] = TMVA.Reader()
    readers = book_readers(readers)

    # Create new tree to add the MVA variable to it.
    new_data_file = TFile(os.path.join(ntuples_dir,decay_name[:-17] + "_data.root"), "recreate")
    new_data_tree = create_tree_with_MVA(data_tree)
    new_data_tree.Write()
    new_data_file.Close()

    new_moca_file = TFile(os.path.join(ntuples_dir,decay_name[:-17] + "_moca.root"), "recreate")
    new_moca_tree = create_tree_with_MVA(moca_tree)
    new_moca_tree.Write()
    new_moca_file.Close()
