# Trains the Machine Learning algorithm on the data. This is a BDT, but it can
# also take other forms like an MLP, etc..

from ROOT import TMVA
from ROOT import TCut,TFile,TTree,TChain,TKey,TString
from sys  import argv
import sys, glob, os, argparse
import array

# Defining a root_dir enables batch processing. Sorry... Change it to the root
# directory of your code tree.
root_dir = "/home/odagiu/"
# Set the root directory of this python project such that imports are easy.
sys.path.append(root_dir)
from util import data_handling as dhand
from util import misc
from util import tmva_selection

# Preamble with input variables and list of studyied decays --------------------
decay_names    = [os.path.basename(path) for path in
                  glob.glob(os.path.join("bcdd_2011d", "*.root"))]

parser = argparse.ArgumentParser(description="Add MVA response to ntuples.")
parser.add_argument('-d', '--decay', default="0",
    choices=["0","1","2","3","4","5","6","7"], help=misc.channel_explanation)
parser.add_argument('-r', '--run', default="1", choices=["1", "2"], help="Run 1 or 2.")
parser.add_argument('-k', '--kfold', default="1",
    choices=["0","1","2","3","4"], help="Number of kfolds.")
parser.add_argument('-n', '--number', default="0", help="Training number.")
args = parser.parse_args()
args.decay = int(args.decay); args.run = int(args.run)

output_dir  = os.path.join(root_dir, "MLclass", "MVAoutput", "BDT_run" +
    str(args.run) + "_" + args.number, "kfold_" + args.kfold)

branches = ["_TAU", "_TAUERR", "_VCHI2", "_PT", "_PIDK", "_M",
            "_M13", "_M23", "_DM"]
method_options = ["MaxDepth=2:UseRandomisedTrees=True",
                  "VarTransform=U:MaxDepth=2:UseRandomisedTrees=True",
                  "VarTransform=G:MaxDepth=2:UseRandomisedTrees=True",
                  "VarTransform=G,D:MaxDepth=2:UseRandomisedTrees=True",
                  "VarTransform=G,P:MaxDepth=2:UseRandomisedTrees=True"]
# End preamble -----------------------------------------------------------------

# Branch alternatives ----------------------------------------------------------
# Raw - branches selected by just looking at the distributions.
# branches = ["_TAU", "_BPVIPCHI2", "_VCHI2", "_PT", "_MIPCHI2DV", "_PIDK",
#             "_M", "_M13", "_M23"]

# Branches selected by Alison in her thesis.
#branches = ["_TAU", "_TAUERR", "_BPVIPCHI2", "_VCHI2", "_PT", "_PIDK",
#            "_M", "_M13", "_M23", "_DM"]

# End --------------------------------------------------------------------------

def add_combined_variables(data_loader, decay_nb):
    """
    Gets and ignores branches depending on the decay. This is for fine tuning
    the MVA.

    @decay_nb  :: Decay number, selected by user.

    @returns :: a list of branches that should be ignored.
    """
    switcher = {
        0: lambda : decay0_combined_branches(data_loader),
        1: lambda : decay1_combined_branches(data_loader),
        2: lambda : decay2_combined_branches(data_loader),
        3: lambda : decay3_combined_branches(data_loader),
        4: lambda : decay4_combined_branches(data_loader),
        5: lambda : decay5_combined_branches(data_loader),
        6: lambda : decay6_combined_branches(data_loader),
        7: lambda : decay7_combined_branches(data_loader)
    }
    func = switcher.get(decay_nb, lambda : "Invalid decay number")
    data_loader = func()

    return data_loader

# The combined branches are commented such as to match decay12 scheme.
def decay0_combined_branches(data_loader):
    # data_loader.AddVariable("p1p2_PIDK := max(p1_PIDK, p2_PIDK)","F")
    # data_loader.AddVariable("p1p2p3_PT := max(max(p1_PT, p2_PT),p3_PT)","F")
    # data_loader.AddVariable("z1z2_PT := max(z1_PT, z2_PT)","F")

    data_loader.AddVariable("Dp_M13_M23_Max := max(Dp_M13, Dp_M23)","F")
    data_loader.AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR","F")
    data_loader.AddVariable("Dp_TAUoTERR := Dp_TAU/Dp_TAUERR","F")
    data_loader.AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR","F")

    return data_loader

def decay1_combined_branches(data_loader):
    # data_loader.AddVariable("p1p2_PIDK := max(p1_PIDK, p2_PIDK)", "F")
    # data_loader.AddVariable("z2z3z4_PIDK := max(max(z2_PIDK, z3_PIDK),z4_PIDK)", "F")
    # data_loader.AddVariable("p1p2p3_PT := max(max(p1_PT, p2_PT),p3_PT)", "F")
    # data_loader.AddVariable("z1z2z3z4_PT := max(max(max(z1_PT, z2_PT),z3_PT),z4_PT)", "F")

    data_loader.AddVariable("Dp_M13_M23_Max := max(Dp_M13, Dp_M23)")
    data_loader.AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR")
    data_loader.AddVariable("Dp_TAUoTERR := Dp_TAU/Dp_TAUERR")
    data_loader.AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR")

    return data_loader

def decay2_combined_branches(data_loader):
    # data_loader.AddVariable("p1p3_PIDK := min(p1_PIDK, p3_PIDK)")
    # data_loader.AddVariable("z1z2_PT := max(z1_PT, z2_PT)")
    # data_loader.AddVariable("p1p2p3_PT := max(max(p1_PT, p2_PT),p3_PT)")

    data_loader.AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR")
    data_loader.AddVariable("Ds_TAUoTERR := Ds_TAU/Ds_TAUERR")
    data_loader.AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR")

    return data_loader

def decay3_combined_branches(data_loader):
    # data_loader.AddVariable("p1p3_PIDK := min(p1_PIDK, p3_PIDK)")
    # data_loader.AddVariable("z2z3z4_PIDK := max(max(z2_PIDK, z3_PIDK),z4_PIDK)")
    # data_loader.AddVariable("p1p2p3_PT := max(max(p1_PT, p2_PT),p3_PT)")
    # data_loader.AddVariable("z1z2z3z4_PT := max(max(max(z1_PT, z2_PT),z3_PT),z4_PT)")

    data_loader.AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR")
    data_loader.AddVariable("Ds_TAUoTERR := Ds_TAU/Ds_TAUERR")
    data_loader.AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR")

    return data_loader

def decay4_combined_branches(data_loader):
    # data_loader.AddVariable("p1p2_PT := max(p1_PT, p2_PT)")
    # data_loader.AddVariable("z1z2_PT := max(z1_PT, z2_PT)")

    data_loader.AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR")
    data_loader.AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR")

    return data_loader

def decay5_combined_branches(data_loader):
    # data_loader.AddVariable("z2z3z4_PIDK := max(max(z2_PIDK, z3_PIDK),z4_PIDK)")
    # data_loader.AddVariable("p1p2_PT := max(p1_PT, p2_PT)")
    # data_loader.AddVariable("z1z2z3z4_PT := max(max(max(z1_PT, z2_PT),z3_PT),z4_PT)")

    data_loader.AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR")
    data_loader.AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR")

    return data_loader

def decay6_combined_branches(data_loader):
    # data_loader.AddVariable("p2p3p4_PIDK := max(max(p2_PIDK, p3_PIDK),p4_PIDK)")
    # data_loader.AddVariable("p1p2p3p4_PT := max(max(max(p1_PT, p2_PT),p3_PT),p4_PT)")
    # data_loader.AddVariable("z1z2_PT := max(z1_PT, z2_PT)")

    data_loader.AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR")
    data_loader.AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR")

    return data_loader

def decay7_combined_branches(data_loader):
    # data_loader.AddVariable("p2p3p4_PIDK := max(max(p2_PIDK, p3_PIDK),p4_PIDK)")
    # data_loader.AddVariable("z2z3z4_PIDK := max(max(z2_PIDK, z3_PIDK),z4_PIDK)")
    # data_loader.AddVariable("p1p2p3p4_PT := max(max(max(p1_PT, p2_PT),p3_PT),p4_PT)")
    # data_loader.AddVariable("z1z2z3z4_PT := max(max(max(z1_PT, z2_PT),z3_PT),z4_PT)")

    data_loader.AddVariable("Bc_TAUoTERR := Bc_TAU/Bc_TAUERR")
    data_loader.AddVariable("Dz_TAUoTERR := Dz_TAU/Dz_TAUERR")

    return data_loader

def add_MVA_variables(data_loader, good_branches):
    """
    Adds the MVA variables to the data_loader object. These are the branches
    that the MVA gets trained on.

    @data_loader :: data_loader object from the MVA import.
    @tree        :: TTree with the list of branches that the MVA should train on.

    @returns     :: The data loader object with the desired branches.
    """
    data_loader = add_combined_variables(data_loader, args.decay)
    for branch in good_branches:
        if branch == "runNumber":
            data_loader.AddSpectator(branch, "F")
        elif branch != "Bc_DTF_M_Bc" and branch != "Bc_M":
            data_loader.AddVariable(branch, "F")

    return data_loader

def get_good_branches(tree):
    ignore   = tmva_selection.get_ignored_branches(args.decay)
    new_tree = tree.CloneTree(-1, "fast")
    new_tree = dhand.branch_selection(new_tree, branches, ignore)
    good_branches = misc.get_active_branches(new_tree)

    return good_branches

if __name__ == '__main__':
    # Prepare the output file and the processing objects.
    decay_name  = decay_names[args.decay]
    decay_output = os.path.join(output_dir, decay_name[:-17])
    misc.create_dir(output_dir)
    misc.create_dir(decay_output)
    output_name = os.path.join(decay_output, decay_name[:-17]) + "_run" + \
                  str(args.run) + ".root"
    output_file = TFile(output_name, "RECREATE")
    factory     = TMVA.Factory("TMVA_" + decay_name[:-17], output_file,
                               "Transformations=I;G;U;D;P:DrawProgressBar=True")
    data_loader = TMVA.DataLoader("dataloader")

    data_tree   = dhand.combine_trees(args.run, decay_name, False)
    moca_tree   = dhand.combine_trees(args.run, decay_name, True)
    data_tree   = dhand.branch_selection(data_tree, branches, [])
    moca_tree   = dhand.branch_selection(moca_tree, branches, [])
    good_brch   = get_good_branches(data_tree)
    data_loader = add_MVA_variables(data_loader, good_brch)

    # Define the cuts on the signal and the background.
    signal_cut  = "&& (Bc_DTF_M_Bc > 5200 && Bc_DTF_M_Bc < 5400)"
    sgcut_test  = TCut("runNumber%5==" + args.kfold + signal_cut)
    sgcut_train = TCut("runNumber%5!=" + args.kfold + signal_cut)
    bgcut_test  = TCut("runNumber%5==" + args.kfold + "&& Bc_DTF_M_Bc > 5400")
    bgcut_train = TCut("runNumber%5!=" + args.kfold + "&& Bc_DTF_M_Bc > 5400")

    # Add the trees to the data loader.
    data_loader.AddTree(data_tree, "Background", 1.0, bgcut_test,  "test")
    data_loader.AddTree(data_tree, "Background", 1.0, bgcut_train, "train")
    data_loader.AddTree(moca_tree, "Signal",     1.0, sgcut_test,  "test")
    data_loader.AddTree(moca_tree, "Signal",     1.0, sgcut_train, "train")

    os.chdir(decay_output)
    data_loader.PrepareTrainingAndTestTree(TCut(""),TCut(""),"")

    # Book the methods and train and test the ML algorithm.
    factory.BookMethod(data_loader, TMVA.Types.kBDT, "BDT_I", method_options[0])
    factory.BookMethod(data_loader, TMVA.Types.kBDT, "BDT_U", method_options[1])
    factory.BookMethod(data_loader, TMVA.Types.kBDT, "BDT_G", method_options[2])
    factory.BookMethod(data_loader, TMVA.Types.kBDT, "BDT_GD",method_options[3])
    factory.BookMethod(data_loader, TMVA.Types.kBDT, "BDT_GP",method_options[4])

    factory.TrainAllMethods()
    factory.TestAllMethods()
    factory.EvaluateAllMethods()

    if args.decay < 4:
        key = output_file.GetListOfKeys().At(1)
        dataset = key.GetName()
    else:
        if args.decay == 7:
            key = output_file.GetListOfKeys().At(1)
            dataset = key.GetName()
        else:
            key = output_file.GetListOfKeys().At(0)
            dataset = key.GetName()
    output_file.Close()

    TMVA.correlations(dataset, output_name)
    TMVA.efficiencies(dataset, output_name)
    TMVA.mvas(dataset, output_name, TMVA.kCompareType)
