#!/bin/bash
python submit.py -d run1_ntp -n decay0 "python MVAntuples.py -d 0 -r 2 -k 5 -m BDT_G -s 12"
python submit.py -d run1_ntp -n decay1 "python MVAntuples.py -d 1 -r 2 -k 5 -m BDT_G -s 12"
python submit.py -d run1_ntp -n decay2 "python MVAntuples.py -d 2 -r 2 -k 5 -m BDT_G -s 12"
python submit.py -d run1_ntp -n decay3 "python MVAntuples.py -d 3 -r 2 -k 5 -m BDT_G -s 12"
python submit.py -d run1_ntp -n decay4 "python MVAntuples.py -d 4 -r 2 -k 5 -m BDT_G -s 12"
python submit.py -d run1_ntp -n decay5 "python MVAntuples.py -d 5 -r 2 -k 5 -m BDT_G -s 12"
python submit.py -d run1_ntp -n decay6 "python MVAntuples.py -d 6 -r 2 -k 5 -m BDT_G -s 12"
python submit.py -d run1_ntp -n decay7 "python MVAntuples.py -d 7 -r 2 -k 5 -m BDT_G -s 12"
