# Slims the big root ntuples to just the important variables used in the TMVA
# process.
from __future__ import division
from ROOT import TCut,TFile,TTree,TChain
import sys, glob, os, argparse
import array

# Defining a root_dir enables batch processing. Sorry... Change it to the root
# directory of your code tree.
root_dir = "/home/odagiu/"
# Set the root directory of this python project such that imports are easy.
sys.path.append(root_dir)
from util import data_handling as dhand
from util import tmva_selection
from util import misc

# Preamble with input variables and list of studyied decays --------------------
decay_names    = [os.path.basename(path) for path in
                  glob.glob(os.path.join("bcdd_2011d", "*.root"))]

parser = argparse.ArgumentParser(description="Add MVA response to ntuples.")
parser.add_argument('-d', '--decay', default="0",
    choices=["0","1","2","3","4","5","6","7"], help=misc.channel_explanation)
parser.add_argument('-r', '--run', default="1",
    choices=["1", "2"], help="Run 1 or 2.")
parser.add_argument('-k', '--kfolds', default="1",
    choices=["1","2","3","4","5"], help="Number of kfolds.")
args = parser.parse_args()
args.decay = int(args.decay); args.run = int(args.run)

branches = ["_TAU", "_TAUERR", "_VCHI2", "_PT", "_PIDK", "_M", "_M13", "_M23", "_DM"]
MLclass_dir = os.path.join(root_dir, "MLclass")
ntuples_dir = os.path.join(MLclass_dir, "slimmed")
# End preamble -----------------------------------------------------------------

def dalitz_merge(tree, particle, masses):
    """
    Merge the Dalitz plots in the tree by doing min(M23,M13) and max(M13,M23).

    @tree     :: The TTree which contains the dalitz variable branches.
    @particle :: The particle which has the dalitz vars.

    @returns  :: TTree with two new branches, min(M13, M23) and max.
    """
    print("Performing Dalitz merge...")
    leaf_min   = particle + masses[0] + masses[1] +"_Min/F"
    leaf_max   = particle + masses[0] + masses[1] +"_Max/F"
    leaf_value_min = array.array("f", [0.0])
    leaf_value_max = array.array("f", [0.0])
    new_branch_dmin = tree.Branch(particle + masses[0] + masses[1] +"_Min",
        leaf_value_min, leaf_min)
    new_branch_dmax = tree.Branch(particle + masses[0] + masses[1] +"_Max",
        leaf_value_max, leaf_max)

    for i in range(tree.GetEntries()):
        tree.GetEntry(i)
        M13 = getattr(tree, particle + masses[0])
        M23 = getattr(tree, particle + masses[1])
        leaf_value_min[0] = min(M13, M23)
        leaf_value_max[0] = max(M13, M23)
        new_branch_dmin.Fill()
        new_branch_dmax.Fill()

    new_tree = tree.CloneTree(-1, "fast")
    tree.Reset()
    return new_tree

def tau_merge(tree, particle):
    """
    Merge TAU and TAUERR branches by diving the former by the latter.

    @tree     :: The TTree which contains the TAU branches.
    @particle :: The particle which has the TAU vars.

    @returns  :: TTree with new branch of TAU/TERR
    """
    print("Performing TAU merge...")
    leaf = particle + "TTERR/F"
    leaf_value = array.array("f", [0.0])
    new_branch_tau = tree.Branch(particle + "_TAUoverTERR", leaf_value, leaf)

    for i in range(tree.GetEntries()):
        tree.GetEntry(i)
        TAU = getattr(tree, particle + "_TAU")
        TER = getattr(tree, particle + "_TAUERR")
        leaf_value[0] = TAU/TER
        new_branch_tau.Fill()

    new_tree = tree.CloneTree(-1, "fast")
    tree.Reset()
    return new_tree

def momentum_merge(tree, particles, part_type):
    """
    Merge the pion/kaon momenta when there are more than 1 pions/kaons in decay.

    @tree     :: The TTree which contains the momenta branches.
    @particle :: Array of strings with momenta that are supposed to be merged.
    @part_type:: Either kaon or pion string.

    @returns  :: TTree with the new momenta branches.
    """
    print("Performing momentum merge...")
    leaf_PIDK = particles[0] + particles[1] + "_PIDK/F"
    leaf_PT   = particles[0] + particles[1] + "_PT/F"
    leaf_value_PIDK = array.array("f", [0.0])
    leaf_value_PT   = array.array("f", [0.0])

    new_branch_PIDK = tree.Branch(particles[0] + particles[1] + \
        "_PIDK", leaf_value_PIDK, leaf_PIDK)
    new_branch_PT   = tree.Branch(particles[0] + particles[1] + \
        "_PT", leaf_value_PT, leaf_PT)

    for i in range(tree.GetEntries()):
        tree.GetEntry(i)
        leaf_value_PIDK[0], leaf_value_PT[0] = \
        get_momentum_values(tree, particles, part_type)
        new_branch_PIDK.Fill()
        new_branch_PT.Fill()

    new_tree = tree.CloneTree(-1, "fast")
    tree.Reset()
    return new_tree

def get_momentum_values(tree, particles, part_type):
    """
    Picks which PIDK is the most likely to be background depending on particle
    and then picks it.

    @tree     :: The TTree which contains the momenta branches.
    @particle :: Array of strings with momenta that are supposed to be merged.
    @part_type:: Either kaon or pion string.

    @returns  :: TTree with the new momenta branches.
    """
    PIDK1 = particles[0] + "_PIDK"; PT1 = particles[0] + "_PT"
    PIDK2 = particles[1] + "_PIDK"; PT2 = particles[1] + "_PT"
    if part_type == "pion":
        if getattr(tree, PIDK1) > getattr(tree, PIDK2):
            PIDK = getattr(tree, PIDK1)
            PT = getattr(tree, PT1)
        else:
            PIDK = getattr(tree, PIDK2)
            PT = getattr(tree, PT2)
    elif part_type == "kaon":
        if getattr(tree, PIDK1) < getattr(tree, PIDK2):
            PIDK = getattr(tree, PIDK1)
            PT = getattr(tree, PT1)
        else:
            PIDK = getattr(tree, PIDK2)
            PT = getattr(tree, PT2)
    else: print("Please give particle type pion or kaon!")

    return PIDK, PT

def decay0_noncorr_branches(tree):
    """
    The Bc2DpDz_PpPpKm_KpPm decay. Selects the non_correlated branches and
    merges the branches that should provide similar information, based on
    various criteria.

    @tree :: TTree with the data for the decay.

    @returns  :: data TTree, monte carlo TTree, and final selection of what
                 branches these two should contain for optimal non_correlation.
    """
    ignored_branches = tmva_selection.decay0_ignored_branches()
    tree = momentum_merge(tree, ["p1","p2"], "pion")
    tree = dalitz_merge(tree,"Dp", ["_M13", "_M23"])
    tree = tau_merge(tree, "Bc")
    tree = tau_merge(tree, "Dp")
    tree = tau_merge(tree, "Dz")
    return tree, ignored_branches

def decay1_noncorr_branches(tree):
    # Decay Bc2DpDz_PpPpKm_KpPmPpPm. See decay0 for functionality.
    ignored_branches = tmva_selection.decay1_ignored_branches()
    tree = momentum_merge(tree, ["p1","p2"], "pion")
    tree = momentum_merge(tree, ["z2","z3"], "pion")
    tree = momentum_merge(tree, ["z2z3", "z4"], "pion")
    tree = dalitz_merge(tree,"Dp", ["_M13", "_M23"])
    tree = tau_merge(tree, "Bc")
    tree = tau_merge(tree, "Dp")
    tree = tau_merge(tree, "Dz")

    return tree, ignored_branches

def decay2_noncorr_branches(tree):
    # Decay Bc2DsDz_KpPpKm_KpPm. See decay0 for functionality.
    ignored_branches = tmva_selection.decay2_ignored_branches()
    tree = momentum_merge(tree, ["p1","p3"], "kaon")
    tree = dalitz_merge(tree,"Ds", ["_M13", "_M23"])
    tree = tau_merge(tree, "Bc")
    tree = tau_merge(tree, "Ds")
    tree = tau_merge(tree, "Dz")

    return tree, ignored_branches

def decay3_noncorr_branches(tree):
    # Decay Bc2DsDz_KpPpKm_KpPmPpPm. See decay0 for functionality.
    ignored_branches = tmva_selection.decay3_ignored_branches()

    tree = momentum_merge(tree, ["p1","p3"], "kaon")
    tree = momentum_merge(tree, ["z2","z3"], "pion")
    tree = momentum_merge(tree, ["z2z3","z4"], "pion")
    tree = dalitz_merge(tree,"Ds", ["_M13", "_M23"])
    tree = tau_merge(tree, "Bc")
    tree = tau_merge(tree, "Ds")
    tree = tau_merge(tree, "Dz")

    return tree, ignored_branches

def decay4_noncorr_branches(tree):
    # Decay Bc2DstDz_KmPp_KpPm. See decay0 for functionality.
    ignored_branches = tmva_selection.decay4_ignored_branches()
    tree = tau_merge(tree, "Bc")
    tree = tau_merge(tree, "Dz")
    return tree, ignored_branches

def decay5_noncorr_branches(tree):
    # Decay Bc2DstDz_KmPp_KpPmPpPm. See decay0 for functionality.
    ignored_branches = tmva_selection.decay5_ignored_branches()
    tree = momentum_merge(tree, ["z2","z3"], "pion")
    tree = momentum_merge(tree, ["z2z3","z4"], "pion")
    tree = tau_merge(tree, "Bc")
    tree = tau_merge(tree, "Dz")
    return tree, ignored_branches

def decay6_noncorr_branches(tree):
    # Decay Bc2DstDz_KmPpPmPp_KpPm. See decay0 for functionality.
    ignored_branches = tmva_selection.decay6_ignored_branches()
    tree = momentum_merge(tree, ["p2","p3"], "pion")
    tree = momentum_merge(tree, ["p2p3","p4"], "pion")
    tree = tau_merge(tree, "Bc")
    tree = tau_merge(tree, "Dz")
    return tree, ignored_branches

def decay7_noncorr_branches(tree):
    # Decay Bc2DstDz_KmPpPmPp_KpPmPpPm. See decay0 for functionality.
    ignored_branches = tmva_selection.decay7_ignored_branches()
    tree = momentum_merge(tree, ["p2","p3"], "pion")
    tree = momentum_merge(tree, ["p2p3","p4"], "pion")
    tree = momentum_merge(tree, ["z2","z3"], "pion")
    tree = momentum_merge(tree, ["z2z3","z4"], "pion")
    tree = tau_merge(tree, "Bc")
    tree = tau_merge(tree, "Dz")

    return tree, ignored_branches

def create_slimmed_ntuple(tree, decay_nb, file_name):
    """
    Based on the decay that used wants, function redirects to the non_correlated
    variable selection for that decay.

    @tree      :: TTree with the data for the decay.
    @decay_nb  :: Decay number, selected by user.

    @returns :: The data and the monte carlo TTrees with the non_correlated
                variables only branches activated + merged branches.
    """
    switcher = {
        0: lambda : decay0_noncorr_branches(tree),
        1: lambda : decay1_noncorr_branches(tree),
        2: lambda : decay2_noncorr_branches(tree),
        3: lambda : decay3_noncorr_branches(tree),
        4: lambda : decay4_noncorr_branches(tree),
        5: lambda : decay5_noncorr_branches(tree),
        6: lambda : decay6_noncorr_branches(tree),
        7: lambda : decay7_noncorr_branches(tree)
    }
    func = switcher.get(decay_nb, lambda : "Invalid decay number")
    tree, ignored_branches = func()

    tree = dhand.branch_selection(tree, branches, ignored_branches)
    slimmed_file = TFile(file_name[:-5] + "_slimmed" + ".root", "recreate")
    slimmed_tree = tree.CloneTree(-1, "fast")
    slimmed_tree.Write(); slimmed_file.Close()

def create_local_stripped_tree(tree, branches, decay_name, moca):
    """
    Activates only the branches that were deemed interesting by looking at their
    plotted distributions and clones the tree such that a local copy that can
    be modified is available.

    @tree :: TTree to be cloned.

    @returns :: Clone of TTree with the essential basic branches activated.
    """
    tree = dhand.branch_selection(tree, branches, [])
    if moca:
        file_name = os.path.join(ntuples_dir,decay_name[:-17]) + "_moca" + ".root"
    else:
        file_name = os.path.join(ntuples_dir,decay_name[:-17]) + "_data" + ".root"
    new_file = TFile(file_name, "recreate")
    new_tree = tree.CloneTree(0)
    for i in range(tree.GetEntries()): tree.GetEntry(i); new_tree.Fill();
    tree.Reset()
    create_slimmed_ntuple(new_tree, args.decay, file_name)
    new_file.Close(); os.remove(file_name)

if __name__ == '__main__':
    # Create the output directory and get the decay name.
    misc.create_dir(ntuples_dir)
    decay_name  = decay_names[args.decay]
    # Get the original simulation data and real data.
    data_tree = dhand.combine_trees(args.run, decay_name, False)
    moca_tree = dhand.combine_trees(args.run, decay_name, True)
    # Create local slimmed ntuples for MVA analysis.
    create_local_stripped_tree(data_tree, branches, decay_name, False)
    create_local_stripped_tree(moca_tree, branches, decay_name, True)
