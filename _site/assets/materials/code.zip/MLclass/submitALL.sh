#!/bin/bash
python submit.py -d run1_bdt$1 -n decay0 "python train.py -d 0 -r 2 -k $2 -n $1"
python submit.py -d run1_bdt$1 -n decay1 "python train.py -d 1 -r 2 -k $2 -n $1"
python submit.py -d run1_bdt$1 -n decay2 "python train.py -d 2 -r 2 -k $2 -n $1"
python submit.py -d run1_bdt$1 -n decay3 "python train.py -d 3 -r 2 -k $2 -n $1"
python submit.py -d run1_bdt$1 -n decay4 "python train.py -d 4 -r 2 -k $2 -n $1"
python submit.py -d run1_bdt$1 -n decay5 "python train.py -d 5 -r 2 -k $2 -n $1"
python submit.py -d run1_bdt$1 -n decay6 "python train.py -d 6 -r 2 -k $2 -n $1"
python submit.py -d run1_bdt$1 -n decay7 "python train.py -d 7 -r 2 -k $2 -n $1"


