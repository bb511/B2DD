# File with short miscellaneous functions.
import data_handling as dhand
import os

def channel_explanation():
    # Assign a number convention to each decay process.

    explain = """ The decay channel numbers coresponds to:
                  0 - Bc2DpDz_PpPpKm_KpPm
                  1 - Bc2DpDz_PpPpKm_KpPmPpPm
                  2 - Bc2DsDz_KpPpKm_KpPm
                  3 - Bc2DsDz_KpPpKm_KpPmPpPm
                  4 - Bc2DstDz_KmPp_KpPm
                  5 - Bc2DstDz_KmPp_KpPmPpPm
                  6 - Bc2DstDz_KmPpPmPp_KpPm
                  7 - Bc2DstDz_KmPpPmPp_KpPmPpPm """

    return explain

def create_dir(dir_name):
    """
    Checks if a certain directory exists and if not, creates one.

    @dir_name :: The path to the directory you want to create, including name.
    """
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)

def get_active_branches(tree):
    good_branches = []
    for branch in tree.GetListOfBranches():
        name = branch.GetName()
        if tree.GetBranchStatus(name) == 1: good_branches.append(name)

    return good_branches

def ignore_particle_PIDK(particles, ignored_branches):
    """
    Gets the name of the momenta that were merged and formulates the full
    branch names such that these can be deactivated.

    @particle :: Array of strings with momenta that are supposed to be merged.
    @ignored_branches :: Array of strings with branches that are deactivated.

    @returns  :: TTree with the new momenta branches.
    """
    for part in particles:
        ignored_branches.append(part + "_PIDK")

    return ignored_branches

def ignore_particle_mome(particles, ignored_branches):
    """
    Gets the name of the momenta that were merged and formulates the full
    branch names such that these can be deactivated.

    @particle :: Array of strings with momenta that are supposed to be merged.
    @ignored_branches :: Array of strings with branches that are deactivated.

    @returns  :: TTree with the new momenta branches.
    """
    for part in particles:
        ignored_branches.append(part + "_PT")

    return ignored_branches

def ignore_particle_tauterr(particles, ignored_branches):
    """
    Gets the name of the lifetimes/errors that were merged and formulates the full
    branch names such that these can be deactivated.

    @particle :: Array of strings with momenta that are supposed to be merged.
    @ignored_branches :: Array of strings with branches that are deactivated.

    @returns  :: TTree with the new momenta branches.
    """
    for part in particles:
        ignored_branches.append(part + "_TAU")
        ignored_branches.append(part + "_TAUERR")

    return ignored_branches
