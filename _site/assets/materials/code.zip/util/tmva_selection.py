# Metadata with branches to be ignored or removed such that the TMVA analysis
# is optimised.
import os
import misc

def get_ignored_branches(decay_nb):
    """
    Gets and ignores branches depending on the decay. This is for fine tuning
    the MVA.

    @decay_nb  :: Decay number, selected by user.

    @returns :: a list of branches that should be ignored.
    """
    switcher = {
        0: lambda : decay0_ignored_branches(),
        1: lambda : decay1_ignored_branches(),
        2: lambda : decay2_ignored_branches(),
        3: lambda : decay3_ignored_branches(),
        4: lambda : decay4_ignored_branches(),
        5: lambda : decay5_ignored_branches(),
        6: lambda : decay6_ignored_branches(),
        7: lambda : decay7_ignored_branches()
    }
    func = switcher.get(decay_nb, lambda : "Invalid decay number")
    ignored_branches = func()

    return ignored_branches

# The comments are such that this matches the decay12 scheme (see website).
def decay0_ignored_branches():
    ignored_branches = ["Dp_M13", "Dp_M23"]
    # ignored_PIDK     = ["p1", "p2"]
    # ignored_mome     = ["p1", "p2", "p3", "z1", "z2"]
    ignored_taus     = ["Bc","Dp","Dz"]
    # ignored_branches = misc.ignore_particle_PIDK(ignored_PIDK, ignored_branches)
    # ignored_branches = misc.ignore_particle_mome(ignored_mome, ignored_branches)
    ignored_branches = misc.ignore_particle_tauterr(ignored_taus, ignored_branches)


    return ignored_branches

def decay1_ignored_branches():
    ignored_branches = ["Dp_M13", "Dp_M23", "Dz_M13", "Dz_M23"]
    # ignored_PIDK     = ["p1", "p2", "z2", "z3", "z2z3", "z4"]
    # ignored_mome     = ["p1", "p2", "p3", "z1", "z2", "z3", "z4"]
    ignored_taus     = ["Bc","Dp","Dz"]
    # ignored_branches = misc.ignore_particle_PIDK(ignored_PIDK, ignored_branches)
    # ignored_branches = misc.ignore_particle_mome(ignored_mome, ignored_branches)
    ignored_branches = misc.ignore_particle_tauterr(ignored_taus, ignored_branches)

    return ignored_branches

def decay2_ignored_branches():
    ignored_branches = ["Ds_VCHI2", "Dz_VCHI2", "Ds_M13"]
    # ignored_PIDK     = ["p1", "p3"]
    # ignored_mome     = ["p1", "p2", "p3", "z1", "z2"]
    ignored_taus     = ["Bc","Ds","Dz"]
    # ignored_branches = misc.ignore_particle_PIDK(ignored_PIDK, ignored_branches)
    # ignored_branches = misc.ignore_particle_mome(ignored_mome, ignored_branches)
    ignored_branches = misc.ignore_particle_tauterr(ignored_taus, ignored_branches)

    return ignored_branches

def decay3_ignored_branches():
    ignored_branches = ["Dz_M13", "Dz_M23", "Ds_VCHI2", "Dz_VCHI2", "Ds_M13"]
    # ignored_PIDK     = ["p1", "p3", "z2", "z3", "z2z3", "z4"]
    # ignored_mome     = ["p1", "p2", "p3", "z1", "z2", "z3", "z4"]
    ignored_taus     = ["Bc","Ds","Dz"]
    # ignored_branches = misc.ignore_particle_PIDK(ignored_PIDK, ignored_branches)
    # ignored_branches = misc.ignore_particle_mome(ignored_mome, ignored_branches)
    ignored_branches = misc.ignore_particle_tauterr(ignored_taus, ignored_branches)

    return ignored_branches

def decay4_ignored_branches():
    ignored_branches = ["Dst_M", "Dst_VCHI2", "ps_PT", "ps_PIDK"]
    # ignored_mome     = ["p1", "p2", "z1", "z2"]
    ignored_taus     = ["Bc","Dzs","Dst","Dz"]
    # ignored_branches = misc.ignore_particle_mome(ignored_mome, ignored_branches)
    ignored_branches = misc.ignore_particle_tauterr(ignored_taus, ignored_branches)
    return ignored_branches

def decay5_ignored_branches():
    ignored_branches = ["Dst_M", "Dst_VCHI2", "ps_PT", "ps_PIDK", "Dz_M13", "Dz_M23"]
    # ignored_PIDK     = ["z2", "z3", "z2z3", "z4"]
    # ignored_mome     = ["p1", "p2", "z1", "z2", "z3", "z4"]
    ignored_taus     = ["Bc","Dzs","Dst","Dz"]
    # ignored_branches = misc.ignore_particle_PIDK(ignored_PIDK, ignored_branches)
    # ignored_branches = misc.ignore_particle_mome(ignored_mome, ignored_branches)
    ignored_branches = misc.ignore_particle_tauterr(ignored_taus, ignored_branches)

    return ignored_branches

def decay6_ignored_branches():
    ignored_branches = ["Dst_M", "Dst_VCHI2", "ps_PT", "ps_PIDK", "Dzs_M13", "Dz_M13", "Dz_M23"]
    # ignored_PIDK     = ["p2", "p3", "p2p3", "p4"]
    # ignored_mome     = ["z1", "z2", "p1", "p2", "p3", "p4"]
    ignored_taus     = ["Bc","Dzs","Dst","Dz"]
    # ignored_branches = misc.ignore_particle_PIDK(ignored_PIDK, ignored_branches)
    # ignored_branches = misc.ignore_particle_mome(ignored_mome, ignored_branches)
    ignored_branches = misc.ignore_particle_tauterr(ignored_taus, ignored_branches)

    return ignored_branches

def decay7_ignored_branches():
    ignored_branches = ["Dst_M", "Dst_VCHI2", "ps_PT", "ps_PIDK", "Dzs_M13", "Dz_M13", "Dz_M23"]
    # ignored_PIDK     = ["z2", "z3", "z2z3", "z4", "p2", "p3", "p2p3", "p4"]
    # ignored_mome     = ["z1", "z2", "z3", "z4", "p1", "p2", "p3", "p4"]
    ignored_taus     = ["Bc","Dzs","Dst","Dz"]
    # ignored_branches = misc.ignore_particle_PIDK(ignored_PIDK, ignored_branches)
    # ignored_branches = misc.ignore_particle_mome(ignored_mome, ignored_branches)
    ignored_branches = misc.ignore_particle_tauterr(ignored_taus, ignored_branches)

    return ignored_branches
